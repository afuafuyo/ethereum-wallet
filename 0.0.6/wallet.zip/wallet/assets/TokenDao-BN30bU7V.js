import{D as o}from"./index-x7PhPwVi.js";class e extends o{constructor(){super(),this.store="tokens"}}export{e as T};
