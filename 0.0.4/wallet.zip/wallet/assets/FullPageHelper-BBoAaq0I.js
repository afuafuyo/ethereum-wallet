class n{static nav(o,e){const l=globalThis,a=l.chrome.runtime.getURL("index.html");l.open(a+"#"+e,"_blank")}}export{n as F};
