import{D as o}from"./index-DIvSfmUZ.js";class e extends o{constructor(){super(),this.store="tokens"}}export{e as T};
