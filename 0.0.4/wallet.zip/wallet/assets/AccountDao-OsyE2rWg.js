import{D as o}from"./index-DIvSfmUZ.js";class c extends o{constructor(){super(),this.store="accounts"}}export{c as A};
