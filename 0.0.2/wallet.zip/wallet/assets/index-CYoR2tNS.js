import{j as o}from"./index-CCA-8g-O.js";function e({children:t}){return o.jsx("div",{style:{paddingBottom:"80px"},children:t})}export{e as P};
