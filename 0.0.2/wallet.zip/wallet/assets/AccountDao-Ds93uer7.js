import{D as o}from"./index-CCA-8g-O.js";class c extends o{constructor(){super(),this.store="accounts"}}export{c as A};
