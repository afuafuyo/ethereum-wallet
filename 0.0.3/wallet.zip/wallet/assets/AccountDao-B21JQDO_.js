import{D as o}from"./index-CtToyOOr.js";class c extends o{constructor(){super(),this.store="accounts"}}export{c as A};
