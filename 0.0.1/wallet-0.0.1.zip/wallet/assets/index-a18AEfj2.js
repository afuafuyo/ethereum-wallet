import{r as v,j as p}from"./index-CWk0DQiS.js";let d=0,s=Date.now(),c=0,e=null,n=null;const A=()=>`#version 300 es
in vec2 a_Position;
uniform vec3 iResolution;
uniform bool iTheme;

void main() {
  gl_Position = vec4(a_Position.xy, 0.0 , 1.0);
}`,T=()=>`#version 300 es
precision mediump float;
out vec4 fragColor;

// shadertoy parameters
uniform vec3 iResolution;
uniform float iTime;
uniform bool iTheme;

void mainImage(out vec4 O, vec2 F) {
  // Iterator and attenuation (distance-squared)
  float i = .2, a;
  // Resolution for scaling and centering
  vec2 r = iResolution.xy,
    // Centered ratio-corrected coordinates
    p = ( F + F - r ) / r.y / 0.8,
    // Diagonal vector for skewing
    d = vec2(-0.5, 1.5),
    // Blackhole center
    b = p - i * d,
    // Rotate and apply perspective
    c = p * mat2(1, 1, d / (.1 + i / dot(b, b))),
    // Rotate into spiraling coordinates
    v = c * mat2(cos(.5 * log(a=dot(c, c)) + iTime * i + vec4(0, 33, 11, 0))) / i,
    // Waves cumulative total for coloring
    w;
    
  // Loop through waves
  for(; i++<9.; w += 1.+sin(v) )
    // Distort coordinates
    v += .8 * sin(v.yx * i + iTime) / i + .5;
  
  // Acretion disk radius
  i = length( sin(v / .3) * .2 + c * (2. + d) );
  // Red/blue gradient
  O = 1. - exp( -exp( c.x * vec4(1.2, -0.8, -1.4, 0.0) )
    // Wave coloring
    / w.xyyx
    // Acretion disk brightness
    / ( 2. + i*i/4. - i )
    // Center darkness
    / ( .4 + 0.8 / a )
    // Rim highlight
    / ( .01 + abs( length(p) - .8 ) )
  );

  if(iTheme) {
    O = vec4(1.0 - O.r, 1.0 - O.g, 1.0 - O.b, 1.0);
  }
}

void main() {
    vec4 col = vec4(0.0, 0.0, 0.0, 1.0);
    mainImage(col, gl_FragCoord.xy);
    // if (col.r < 0.1 && col.g < 0.1 && col.b < 0.1) {
    //     col.a = 1.0;
    // }
    
    fragColor = col;
}`;function m(o,i,r){const t=o.createShader(i);if(o.shaderSource(t,r),o.compileShader(t),!o.getShaderParameter(t,o.COMPILE_STATUS))throw new Error("An error occurred compiling v shaders: "+o.getShaderInfoLog(t));return t}function R(o,i,r){const t=o.createProgram();if(o.attachShader(t,i),o.attachShader(t,r),o.linkProgram(t),o.useProgram(t),!o.getProgramParameter(t,o.LINK_STATUS))throw new Error("Unable to initialize the shader program: "+o.getProgramInfoLog(t));return t}const b=o=>{if(e=document.getElementById("shader_canvas").getContext("webgl2",{alpha:!0}),!e)throw new Error("WebGL2 is not supported in your browser");const r=m(e,e.VERTEX_SHADER,A()),t=m(e,e.FRAGMENT_SHADER,T());n=R(e,r,t);const u=[0,3,2,-1,-2,-1],h=e.createBuffer();e.bindBuffer(e.ARRAY_BUFFER,h),e.bufferData(e.ARRAY_BUFFER,new Float32Array(u),e.STATIC_DRAW);const a=e.getAttribLocation(n,"a_Position");e.vertexAttribPointer(a,2,e.FLOAT,!1,0,0),e.enableVertexAttribArray(a);const f=e.getUniformLocation(n,"iResolution");e.uniform3f(f,e.canvas.width,e.canvas.height,1);const g=e.getUniformLocation(n,"iTheme");e.uniform1i(g,o),e.clearColor(0,0,0,0),e.clear(e.COLOR_BUFFER_BIT|e.DEPTH_BUFFER_BIT),l()};function l(){if(!e||!n)return;const o=Date.now(),i=(o-s)*.001;c+=i,s=o;const r=e.getUniformLocation(n,"iTime");e.uniform1f(r,c),e.drawArrays(e.TRIANGLES,0,3),d=requestAnimationFrame(l)}function E(o){const i=globalThis.innerWidth;let r=i*1;return r=Math.min(globalThis.innerHeight,r),v.useEffect(()=>{const t=o.dark?0:1;return b(t),()=>{cancelAnimationFrame(d)}},[]),p.jsx("canvas",{id:"shader_canvas",width:i,height:r,style:{position:"absolute",zIndex:1,top:0,left:0,pointerEvents:"none"}})}export{E as H};
