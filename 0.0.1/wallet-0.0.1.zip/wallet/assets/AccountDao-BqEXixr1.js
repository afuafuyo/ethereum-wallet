import{D as o}from"./index-CWk0DQiS.js";class c extends o{constructor(){super(),this.store="accounts"}}export{c as A};
