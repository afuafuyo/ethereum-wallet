import{D as o}from"./index-BFdjePAA.js";class c extends o{constructor(){super(),this.store="accounts"}}export{c as A};
